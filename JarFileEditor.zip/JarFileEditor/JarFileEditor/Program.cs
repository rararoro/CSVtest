﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace JarFileEditor
{
    class JarFile {
        private string fileName;
        private string directoryName;
        private string baseName;
        private string filePath;
        private string jarExePath;
        private ArrayList datFiles;
        private ArrayList osvDatFile;
        private ArrayList fotaDatFile;

        public JarFile(){
            
            fileName="";
            directoryName="";
            baseName = "";
            filePath = "";
            jarExePath="";
            datFiles =new ArrayList();
            osvDatFile = new ArrayList();
            fotaDatFile = new ArrayList();
            }

        public string FileName{
            set{ this.fileName = value;}
            get { return this.fileName; }
            
            }
        public string DirectoryName {

            set { this.directoryName = value; }
            get { return this.directoryName; }
        }
        public string BaseName
        {

            set { this.baseName = value; }
            get { return this.baseName; }
        }
        public string FilePath
        {

            set { this.filePath = value; }
            get { return this.filePath; }
        }
        public string JarExePath
        {
            set { this.jarExePath = value; }
            get { return this.jarExePath; }
        }
       
        public ArrayList DatFiles1
        {
            get
            {
                return datFiles;
            }

            set
            {
                datFiles = value;
            }
        }
        public ArrayList OsvDatFile
        {
            get
            {
                return osvDatFile;
            }

            set
            {
                osvDatFile = value;
            }
        }
        public ArrayList FotaDatFile
        {
            get {
                return fotaDatFile;
            }

            set {
                fotaDatFile = value;
            }
            

        }

    }


    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
